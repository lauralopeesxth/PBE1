package prjExercicio01;

public class Aplicacao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Carro marca = new Carro();
		carro01.marca = "Chevrolet";
		
		Carro modelo = new Carro();
		carro01.modelo = "Tracker";
		
		Carro placa = new Carro();
		carro01.placa = "";
		
		Carro ano = new Carro();
		carro01.ano = "2024";
		
		
		

	}

}
