package prjExercicio01;

public class Carro {
	
	//Atributos
	String marca;
    String modelo;
	String placa;
	String ano;
	
	//Construtores
	public Carro() {
		
	}
	public Carro(String marca,String modelo, String placa, String ano) {
		this.marca = marca;
		this.modelo = modelo;
		this.placa = placa;
		this.ano = ano;
	}
	
	//Metodods
	public void exibirInfo() {
		System.out.println();
	
	}
	
}
	