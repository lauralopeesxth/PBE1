package prjExercicio02;

public class Livro {
 
	//Atributos 
	String titulo;
	String autor;
	int numPaginas;
	double preco;
	
	//Construtores
	public Livro() {
		
	}
	
	public Livro(String titulo,String autor, int numPaginas, double preco) {
		this.titulo = titulo;
		this.autor = autor;
		this.numPaginas = numPaginas;
		this.preco = preco;
	}
	
	//Getters Setters
	public String getTitulo() {
		return titulo; 
		
	}
	public void setTitulo(String titulo) {
		 this.titulo= titulo;
	 }
	
	 public String getAutor() {
		 return this.autor;
		 
	 }
	 public void setAutor(String autor) {
		 this.autor = autor;
	 }
	 public int getNumPaginas() {
		 return numPaginas;
		  
	 }
	 
	 
	 
}
