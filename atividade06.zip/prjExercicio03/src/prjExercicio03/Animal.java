package prjExercicio03;

public class Animal {
   
	//Atributos
	String nome;
	int idade;
	String raca;
	
	
	// Construtor padrao
	public Animal() {
		this.nome = "";
		this.raca = "";
		this.idade = 2;
	}
	
	// Construtores parametrizado
	public Animal(String nome, String raca, int idade) {
		this.nome = nome;
		this.raca = raca;
		this.idade = idade;
		
	}
	
	//Metodos
	public void emitirSom() {
		System.out.println("O animal fez um som");
	}
}
