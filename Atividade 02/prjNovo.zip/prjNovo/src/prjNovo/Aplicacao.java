package prjNovo;

public class Aplicacao {

}
