package prjCarro;

import java.util.Scanner;

public class AndarDeCarro {

	public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        
        System.out.println("Qual é a marca do carro?");
        String marca = sc .next();
        
        System.out.println("Qual é a modelo do carro?");
        String modelo = sc .next();
        
        System.out.println("Qual é a velocidade do carro em km/h ?");
        int velocidade = sc .nextInt();
        
        System.out.println("Quer acelerar ou desacelerar? \n 1) Acelerar\n 2 Desacelerar");
        int opcao = sc .nextInt();
        
        if(opcao == 1) {
        	System.out.println("Quanto ira acelerar? ");
        	int aceleracao = sc .nextInt();
        	velocidade += aceleracao;
        	
        	else if (opcao == 2) {
        		System.out.println("Quanto ira desacelerar? ");
        		int desaceleracao = sc .nextInt();
                velocidade -= desaceleracao;
        	}
        	else {
        		System.out.print("Voce se manteve na mesma velocidade \n ");
        	}
        	
        
        
        
        
         
            
	}

}
