package prjCarro;

import java.util.Scanner;

public class NovoCarro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		Carro carro01 = new Carro();
		Carro carro02 = new Carro("VW","GOL", 0);
		
		
		System.out.println("Qual a marca ?");
		carro01.setMarca(sc.nextLine());
		
		System.out.println("Qual o modelo ?");
		carro01.setModelo(sc.nextLine());
		
		System.out.println("Qual a velocidade?");
		carro01.setVelocidade(sc.nextInt());
		
		System.out.println("Opçoes:");
		System.out.println("1. Acelerar");
		System.out.println("2. Frear");
		System.out.println("3. Buzina");
		System.out.println("Escolha uma opçao:");
		int escolha = sc.nextInt();
		
		if (escolha == 1) {
			System.out.println("Quanto voce quer acelerar?");
			carro01.acelerar(sc.nextInt());
			
		}
		else if (escolha == 2) {
			System.out.println("Quanto voce quer desacelerar?");
			carro01.frear(sc.nextInt());
		}
		else if (escolha == 3) {
			carro01.buzinar();
		}
		
		else {
			System.out.println("Opçao invalida.");
			
		}
		
		System.out.println("Marca: " + carro01.getMarca());
		System.out.println("Modelo: " + carro01.getModelo());
		System.out.println("velocidade: " + carro01.getVelocidade());
		
		
		
		
		
	}

}
