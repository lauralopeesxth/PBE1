package prjBibliotecaSenai;

public class Usuario extends Pessoa {
	
	//atributos
	private int CPF;
	private int livrosEmprestados;
	
	// gettes e setters
	public int getCPF() {
		return CPF;
	}
	
	
	public void setCPF(int cPF) {
		CPF = cPF;
	}
	public int getLivrosEmprestados () {
		return livrosEmprestados;
		
	}
	

	public void setLivrosEmprestados (int livrosEmprestados) {
		this. livrosEmprestados = livrosEmprestados;
	}
	

}
