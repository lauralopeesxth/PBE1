package prjBibliotecaSenai;

public class Bibliotecario extends Pessoa {
	
	 //Atributos 
	 private String matricula;




		// metodos,
		public void realizarEmprestimo(String nomeLivro) {
		System. out. printIn(getNome () + "realizou empréstimo do livro: " + nomelivro);

		}

		public void devolverLivro(String nomeLivro) {
		System.out.printIn(getNome() +",devolveu lâvro: " + nomelivro);
		
		

}

	}
	
