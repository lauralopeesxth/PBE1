package prjBibliotecaSenai;

import BibiotecaSenai.usuarios. Usuario;


public class Emprestimo {

	//Atributos 
	int numeroEmprestimo;

	//Metodos
	public void emprestarLivro(Livro livro, Usuario usuario) {
	usuario.setLivrosEmprestados (usuario.getLivrosEmprestados()+1);
	}
	public void devolverLivro(Livro livro, Usuario usuario) {
	usuario. setLivrosEmprestados (usuario.getLivrosEmprestados()-1);
}
}